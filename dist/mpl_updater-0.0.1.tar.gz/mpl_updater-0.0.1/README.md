A package that allows a Matplotlib plot to be run directly from a file and then adjusts changes made in the code directly without having to restart the animation.

It is supposed to end up on pypi. Currently does not support full exception handling, so still in development.
